<?php
  $con = mysqli_connect("localhost","root","",'Register') or die(mysqli_error());
?><?php