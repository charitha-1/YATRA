<?php 
    session_start();
    include("db.php");
    if($_SERVER['REQUEST_METHOD']=="POST")
    {
        $uname = $_POST['uname'];
        $num = $_POST['number'];
        $gmail = $_POST['mail'];
        $password = $_POST['pass'];

        if(!empty($gmail) && !empty($password) && !is_numeric($gmail))
        {
          $query = "insert into form (uname, cnum, email, pass) values ('$uname','$num','$gmail','$password')";
          mysqli_query($con,$query);
          echo "<script type='text/javascript'> alert('Sucessfully Register')</script>";
        }
        echo "<script type='text/javascript'> alert('Enter valid details')</script>";
    }
?>
